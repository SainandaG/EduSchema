-- Create Database
CREATE DATABASE IF NOT EXISTS EduSchema;
USE EduSchema;

CREATE TABLE IF NOT EXISTS Courses (
    courseID INT AUTO_INCREMENT PRIMARY KEY,
    courseName VARCHAR(100) NOT NULL,
    courseDescription TEXT NOT NULL,
    startDate DATE NOT NULL,
    endDate DATE NOT NULL
);

-- Create Instructors Table
CREATE TABLE IF NOT EXISTS Instructors (
    instructorID INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15)
);

-- Create Students Table
CREATE TABLE IF NOT EXISTS Students (
    studentID INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15)
);

-- Create Enrollments Table
CREATE TABLE IF NOT EXISTS Enrollments (
    enrollmentID INT AUTO_INCREMENT PRIMARY KEY,
    studentID INT NOT NULL,
    courseID INT NOT NULL,
    progress DECIMAL(5, 2) DEFAULT 0.00,
    FOREIGN KEY (studentID) REFERENCES Students(studentID),
    FOREIGN KEY (courseID) REFERENCES Courses(courseID)
);

-- Create Assignments Table
CREATE TABLE IF NOT EXISTS Assignments (
    assignmentID INT AUTO_INCREMENT PRIMARY KEY,
    assignmentName VARCHAR(100) NOT NULL,
    dueDate DATE NOT NULL
);

-- Create Grades Table
CREATE TABLE IF NOT EXISTS Grades (
    gradeID INT AUTO_INCREMENT PRIMARY KEY,
    studentID INT NOT NULL,
    assignmentID INT NOT NULL,
    grade DECIMAL(5, 2) NOT NULL,
    FOREIGN KEY (studentID) REFERENCES Students(studentID),
    FOREIGN KEY (assignmentID) REFERENCES Assignments(assignmentID)
);

-- Create CourseInstructors Table
CREATE TABLE IF NOT EXISTS CourseInstructors (
    courseInstructorID INT AUTO_INCREMENT PRIMARY KEY,
    courseID INT NOT NULL,
    instructorID INT NOT NULL,
    FOREIGN KEY (courseID) REFERENCES Courses(courseID),
    FOREIGN KEY (instructorID) REFERENCES Instructors(instructorID)
);

-- Create deleted_entities Table (for tracking deletions)
CREATE TABLE IF NOT EXISTS deleted_entities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entity_type VARCHAR(255) NOT NULL,
    entity_id INT NOT NULL,
    deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    additional_info JSON
);

-- Show auto_increment variables for verification
SHOW VARIABLES LIKE 'auto_increment%';
