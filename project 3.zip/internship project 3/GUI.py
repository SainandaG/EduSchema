import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from mysql.connector import Error
import script  # Importing our database script

def main():
    root = tk.Tk()
    root.title("EduSchema Management System")
    root.geometry("800x600")

    tab_control = ttk.Notebook(root)

    # Define tabs
    tabs = [
        ("Courses", add_course_management),
        ("Instructors", add_instructor_management),
        ("Students", add_student_management),
        ("Enrollments", add_enrollment_management),
        ("Assignments", add_assignment_management),
        ("Grades", add_grade_management),
        ("Deleted Entities", add_deleted_entities_management)
    ]

    for tab_name, tab_func in tabs:
        tab = ttk.Frame(tab_control)
        tab_control.add(tab, text=tab_name)
        tab_func(tab)

    tab_control.pack(expand=1, fill="both")

    root.mainloop()

def add_course_management(tab):
    # Course management UI elements
    tk.Label(tab, text="Course Name:").grid(row=0, column=0, padx=10, pady=10)
    entry_course_name = tk.Entry(tab)
    entry_course_name.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(tab, text="Course Description:").grid(row=1, column=0, padx=10, pady=10)
    entry_course_desc = tk.Entry(tab)
    entry_course_desc.grid(row=1, column=1, padx=10, pady=10)

    tk.Label(tab, text="Start Date (YYYY-MM-DD  ):").grid(row=2, column=0, padx=10, pady=10)
    entry_start_date = tk.Entry(tab)
    entry_start_date.grid(row=2, column=1, padx=10, pady=10)

    tk.Label(tab, text="End Date (YYYY-MM-DD):").grid(row=3, column=0, padx=10, pady=10)
    entry_end_date = tk.Entry(tab)
    entry_end_date.grid(row=3, column=1, padx=10, pady=10)

    def add_course():
        course_name = entry_course_name.get()
        course_desc = entry_course_desc.get()
        start_date = entry_start_date.get()
        end_date = entry_end_date.get()

        connection = script.create_connection()
        if connection:
            query = "INSERT INTO Courses (courseName, courseDescription, startDate, endDate) VALUES (%s, %s, %s, %s)"
            success = script.execute_query(connection, query, (course_name, course_desc, start_date, end_date))
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Course added successfully")
            else:
                messagebox.showerror("Error", "Failed to add course")

    def delete_course():
        course_id = entry_course_id.get()
        if not course_id:
            messagebox.showerror("Input Error", "Course ID is required")
            return

        connection = script.create_connection()
        if connection:
            query = "DELETE FROM Courses WHERE courseID = %s"
            success = script.execute_query(connection, query, (course_id,))
            script.log_deletion('Course', course_id)
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Course deleted successfully")
            else:
                messagebox.showerror("Error", "Failed to delete course")

    tk.Button(tab, text="Add Course", command=add_course).grid(row=4, column=0, columnspan=2, pady=20)
    tk.Label(tab, text="Course ID to Delete:").grid(row=5, column=0, padx=10, pady=10)
    entry_course_id = tk.Entry(tab)
    entry_course_id.grid(row=5, column=1, padx=10, pady=10)
    tk.Button(tab, text="Delete Course", command=delete_course).grid(row=6, column=0, columnspan=2, pady=20)

def add_instructor_management(tab):
    # Instructor management UI elements
    tk.Label(tab, text="First Name:").grid(row=0, column=0, padx=10, pady=10)
    entry_first_name = tk.Entry(tab)
    entry_first_name.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(tab, text="Last Name:").grid(row=1, column=0, padx=10, pady=10)
    entry_last_name = tk.Entry(tab)
    entry_last_name.grid(row=1, column=1, padx=10, pady=10)

    tk.Label(tab, text="Email:").grid(row=2, column=0, padx=10, pady=10)
    entry_email = tk.Entry(tab)
    entry_email.grid(row=2, column=1, padx=10, pady=10)

    tk.Label(tab, text="Phone:").grid(row=3, column=0, padx=10, pady=10)
    entry_phone = tk.Entry(tab)
    entry_phone.grid(row=3, column=1, padx=10, pady=10)

    def add_instructor():
        first_name = entry_first_name.get()
        last_name = entry_last_name.get()
        email = entry_email.get()
        phone = entry_phone.get()

        connection = script.create_connection()
        if connection:
            query = "INSERT INTO Instructors (firstName, lastName, email, phone) VALUES (%s, %s, %s, %s)"
            success = script.execute_query(connection, query, (first_name, last_name, email, phone))
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Instructor added successfully")
            else:
                messagebox.showerror("Error", "Failed to add instructor")

    def delete_instructor():
        instructor_id = entry_instructor_id.get()
        if not instructor_id:
            messagebox.showerror("Input Error", "Instructor ID is required")
            return

        connection = script.create_connection()
        if connection:
            query = "DELETE FROM Instructors WHERE instructorID = %s"
            success = script.execute_query(connection, query, (instructor_id,))
            script.log_deletion('Instructor', instructor_id)
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Instructor deleted successfully")
            else:
                messagebox.showerror("Error", "Failed to delete instructor")

    tk.Button(tab, text="Add Instructor", command=add_instructor).grid(row=4, column=0, columnspan=2, pady=20)
    tk.Label(tab, text="Instructor ID to Delete:").grid(row=5, column=0, padx=10, pady=10)
    entry_instructor_id = tk.Entry(tab)
    entry_instructor_id.grid(row=5, column=1, padx=10, pady=10)
    tk.Button(tab, text="Delete Instructor", command=delete_instructor).grid(row=6, column=0, columnspan=2, pady=20)

def add_student_management(tab):
    # Student management UI elements (similar structure as add_instructor_management)
    tk.Label(tab, text="First Name:").grid(row=0, column=0, padx=10, pady=10)
    entry_first_name = tk.Entry(tab)
    entry_first_name.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(tab, text="Last Name:").grid(row=1, column=0, padx=10, pady=10)
    entry_last_name = tk.Entry(tab)
    entry_last_name.grid(row=1, column=1, padx=10, pady=10)

    tk.Label(tab, text="Email:").grid(row=2, column=0, padx=10, pady=10)
    entry_email = tk.Entry(tab)
    entry_email.grid(row=2, column=1, padx=10, pady=10)

    tk.Label(tab, text="Phone:").grid(row=3, column=0, padx=10, pady=10)
    entry_phone = tk.Entry(tab)
    entry_phone.grid(row=3, column=1, padx=10, pady=10)

    def add_student():
        first_name = entry_first_name.get()
        last_name = entry_last_name.get()
        email = entry_email.get()
        phone = entry_phone.get()

        connection = script.create_connection()
        if connection:
            query = "INSERT INTO Students (firstName, lastName, email, phone) VALUES (%s, %s, %s, %s)"
            success = script.execute_query(connection, query, (first_name, last_name, email, phone))
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Student added successfully")
            else:
                messagebox.showerror("Error", "Failed to add student")

    def delete_student():
        student_id = entry_student_id.get()
        if not student_id:
            messagebox.showerror("Input Error", "Student ID is required")
            return

        connection = script.create_connection()
        if connection:
            query = "DELETE FROM Students WHERE studentID = %s"
            success = script.execute_query(connection, query, (student_id,))
            script.log_deletion('Student', student_id)
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Student deleted successfully")
            else:
                messagebox.showerror("Error", "Failed to delete student")

    tk.Button(tab, text="Add Student", command=add_student).grid(row=4, column=0, columnspan=2, pady=20)
    tk.Label(tab, text="Student ID to Delete:").grid(row=5, column=0, padx=10, pady=10)
    entry_student_id = tk.Entry(tab)
    entry_student_id.grid(row=5, column=1, padx=10, pady=10)
    tk.Button(tab, text="Delete Student", command=delete_student).grid(row=6, column=0, columnspan=2, pady=20)

def add_enrollment_management(tab):
    # Enrollment management UI elements (similar structure as add_instructor_management)
    tk.Label(tab, text="Student ID:").grid(row=0, column=0, padx=10, pady=10)
    entry_student_id = tk.Entry(tab)
    entry_student_id.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(tab, text="Course ID:").grid(row=1, column=0, padx=10, pady=10)
    entry_course_id = tk.Entry(tab)
    entry_course_id.grid(row=1, column=1, padx=10, pady=10)

    def add_enrollment():
        student_id = entry_student_id.get()
        course_id = entry_course_id.get()

        if not student_id or not course_id:
            messagebox.showerror("Input Error", "Student ID and Course ID are required")
            return

        connection = script.create_connection()
        if connection:
            query = "INSERT INTO Enrollments (studentID, courseID) VALUES (%s, %s)"
            success = script.execute_query(connection, query, (student_id, course_id))
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Enrollment added successfully")
            else:
                messagebox.showerror("Error", "Failed to add enrollment")

    def delete_enrollment():
        enrollment_id = entry_enrollment_id.get()
        if not enrollment_id:
            messagebox.showerror("Input Error", "Enrollment ID is required")
            return

        connection = script.create_connection()
        if connection:
            query = "DELETE FROM Enrollments WHERE enrollmentID = %s,%s"
            success = script.execute_query(connection, query, (enrollment_id,))
            script.log_deletion('Enrollment', enrollment_id)
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Enrollment deleted successfully")
            else:
                messagebox.showerror("Error", "Failed to delete enrollment")

    tk.Button(tab, text="Add Enrollment", command=add_enrollment).grid(row=2, column=0, columnspan=2, pady=20)
    tk.Label(tab, text="Enrollment ID to Delete:").grid(row=3, column=0, padx=10, pady=10)
    entry_enrollment_id = tk.Entry(tab)
    entry_enrollment_id.grid(row=3, column=1, padx=10, pady=10)
    tk.Button(tab, text="Delete Enrollment", command=delete_enrollment).grid(row=4, column=0, columnspan=2, pady=20)

def add_assignment_management(tab):
    # Assignment management UI elements (similar structure as add_instructor_management)
    tk.Label(tab, text="Assignment Name:").grid(row=0, column=0, padx=10, pady=10)
    entry_assignment_name = tk.Entry(tab)
    entry_assignment_name.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(tab, text="Due Date (YYYY-MM-DD):").grid(row=2, column=0, padx=10, pady=10)
    entry_due_date = tk.Entry(tab)
    entry_due_date.grid(row=2, column=1, padx=10, pady=10)

    def add_assignment():
        assignment_name = entry_assignment_name.get()
        due_date = entry_due_date.get()

        connection = script.create_connection()
        if connection:
            query = "INSERT INTO Assignments (assignmentName,  dueDate) VALUES ( %s, %s)"
            success = script.execute_query(connection, query, (assignment_name,  due_date))
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Assignment added successfully")
            else:
                messagebox.showerror("Error", "Failed to add assignment")

    def delete_assignment():
        assignment_id = entry_assignment_id.get()
        if not assignment_id:
            messagebox.showerror("Input Error", "Assignment ID is required")
            return

        connection = script.create_connection()
        if connection:
            query = "DELETE FROM Assignments WHERE assignmentID = %s"
            success = script.execute_query(connection, query, (assignment_id,))
            script.log_deletion('Assignment', assignment_id)
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Assignment deleted successfully")
            else:
                messagebox.showerror("Error", "Failed to delete assignment")

    tk.Button(tab, text="Add Assignment", command=add_assignment).grid(row=3, column=0, columnspan=2, pady=20)
    tk.Label(tab, text="Assignment ID to Delete:").grid(row=4, column=0, padx=10, pady=10)
    entry_assignment_id = tk.Entry(tab)
    entry_assignment_id.grid(row=4, column=1, padx=10, pady=10)
    tk.Button(tab, text="Delete Assignment", command=delete_assignment).grid(row=5, column=0, columnspan=2, pady=20)

def add_grade_management(tab):
    # Grade management UI elements (similar structure as add_instructor_management)
    tk.Label(tab, text="Student ID:").grid(row=0, column=0, padx=10, pady=10)
    entry_student_id = tk.Entry(tab)
    entry_student_id.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(tab, text="Assignment ID:").grid(row=1, column=0, padx=10, pady=10)
    entry_assignment_id = tk.Entry(tab)
    entry_assignment_id.grid(row=1, column=1, padx=10, pady=10)

    tk.Label(tab, text="Grade:").grid(row=2, column=0, padx=10, pady=10)
    entry_grade = tk.Entry(tab)
    entry_grade.grid(row=2, column=1, padx=10, pady=10)

    def add_grade():
        student_id = entry_student_id.get()
        assignment_id = entry_assignment_id.get()
        grade = entry_grade.get()

        if not student_id or not assignment_id or not grade:
            messagebox.showerror("Input Error", "Student ID, Assignment ID, and Grade are required")
            return

        connection = script.create_connection()
        if connection:
            query = "INSERT INTO Grades (studentID, assignmentID, grade) VALUES (%s, %s, %s)"
            success = script.execute_query(connection, query, (student_id, assignment_id, grade))
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Grade added successfully")
            else:
                messagebox.showerror("Error", "Failed to add grade")

    def delete_grade():
        grade_id = entry_grade_id.get()
        if not grade_id:
            messagebox.showerror("Input Error", "Grade ID is required")
            return

        connection = script.create_connection()
        if connection:
            query = "DELETE FROM Grades WHERE gradeID = %s"
            success = script.execute_query(connection, query, (grade_id,))
            script.log_deletion('Grade', grade_id)
            script.close_connection(connection)

            if success:
                messagebox.showinfo("Success", "Grade deleted successfully")
            else:
                messagebox.showerror("Error", "Failed to delete grade")

    tk.Button(tab, text="Add Grade", command=add_grade).grid(row=3, column=0, columnspan=2, pady=20)
    tk.Label(tab, text="Grade ID to Delete:").grid(row=4, column=0, padx=10, pady=10)
    entry_grade_id = tk.Entry(tab)
    entry_grade_id.grid(row=4, column=1, padx=10, pady=10)
    tk.Button(tab, text="Delete Grade", command=delete_grade).grid(row=5, column=0, columnspan=2, pady=20)

def add_deleted_entities_management(tab):
    # Deleted entities management UI (showing deleted records from deleted_entities table)
    columns = ("entity_type", "entity_id", "deleted_at", "additional_info")
    treeview = ttk.Treeview(tab, columns=columns, show="headings")

    for col in columns:
        treeview.heading(col, text=col)

    treeview.grid(row=0, column=0, sticky="nsew")

    def refresh_deleted_entities():
        for item in treeview.get_children():
            treeview.delete(item)
        
        connection = script.create_connection()
        if connection:
            query = "SELECT * FROM deleted_entities"
            records = script.fetch_data(connection, query)
            if records:
                for row in records:
                    treeview.insert("", "end", values=row)
            script.close_connection(connection)

    refresh_button = tk.Button(tab, text="Refresh", command=refresh_deleted_entities)
    refresh_button.grid(row=1, column=0, pady=10)

# Start the application
if __name__ == "__main__":
    main()
